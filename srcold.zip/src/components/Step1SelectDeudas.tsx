// src/components/Step1SelectDeudas.tsx
import React, { memo, useCallback } from 'react';
import { Invoice } from '../types/invoice';
import { InvoiceCard } from './InvoiceCard';
import { FilterBar } from './FilterBar';
import { FileText, CheckSquare, XSquare, AlertTriangle } from 'lucide-react';
import { useInvoiceContext } from '../context/InvoiceContext'; // Import the context

interface Step1Props {
    invoices: Invoice[];
    searchTerm: string;
    statusFilter: string;
    sortBy: "dueDate" | "amount" | "supplier";
    sortOrder: 'asc' | 'desc';
    onSearchChange: (term: string) => void;
    onStatusFilterChange: (status: string) => void;
    onSortChange: (sortBy: "dueDate" | "amount" | "supplier") => void;
    onSortOrderChange: (order: 'asc' | 'desc') => void;
}

const Step1SelectDeudasComponent: React.FC<Step1Props> = ({
    invoices,
    searchTerm,
    statusFilter,
    sortBy,
    sortOrder,
    onSearchChange,
    onStatusFilterChange,
    onSortChange,
    onSortOrderChange,
}) => {
    const { selectedInvoiceIds, handleInvoiceSelection, selectAllInvoices, selectOverdueInvoices, clearSelection, updatePaymentSummary, fetchBankDetails, setCurrentStep, fetchAvailableBanks, cedula, apiToken } = useInvoiceContext(); // Get context values
    const hasSelection = selectedInvoiceIds.size > 0;



    const handleInvoiceSelectionWrapper = useCallback(
        (invoiceId: string, isSelected: boolean) => {
            handleInvoiceSelection(invoiceId, isSelected);
            updatePaymentSummary(); // Update the payment summary after selection changes
        },
        [handleInvoiceSelection, updatePaymentSummary]
    );

    const handleSelectAllWrapper = useCallback(() => {
        selectAllInvoices();
        updatePaymentSummary();
    }, [selectAllInvoices, updatePaymentSummary]);

    const handleSelectOverdueWrapper = useCallback(() => {
        selectOverdueInvoices();
        updatePaymentSummary();
    }, [selectOverdueInvoices, updatePaymentSummary]);

    const handleClearSelectionWrapper = useCallback(() => {
        clearSelection();
        updatePaymentSummary();
    }, [clearSelection, updatePaymentSummary]);

    const handleNext = useCallback(async () => {
        if (!hasSelection) {
            alert("Por favor, seleccione al menos una deuda antes de continuar.");
            return;
        }

        updatePaymentSummary(); // UPDATE PAYMENT SUMMARY BEFORE FETCHING BANK DETAILS

        try {
            // await fetchBankDetails(cedula, apiToken); // Fetch bank details
            await fetchAvailableBanks(cedula, apiToken); // Load the available banks
            setCurrentStep(2);
            // setCurrentStep(3); // Move to Step 3 after fetching details
        } catch (error: any) {
            alert(`Error fetching bank details: ${error.message}`);
            // Handle error as needed (e.g., display error message)
        }
    }, [hasSelection, setCurrentStep, cedula, apiToken, updatePaymentSummary, fetchAvailableBanks]); // ADD updatePaymentSummary


    return (
        <div className="space-y-4">
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-4 border border-blue-200">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    Paso 1: Seleccionar Deudas
                </h3>
                <p className="text-gray-600 text-sm">
                    Elige las deudas a pagar. Puedes usar los filtros para encontrar deudas específicas.
                </p>
            </div>

            <FilterBar
                searchTerm={searchTerm}
                onSearchChange={onSearchChange}
                statusFilter={statusFilter}
                onStatusFilterChange={onStatusFilterChange}
                sortBy={sortBy}
                onSortChange={onSortChange}
                sortOrder={sortOrder}
                onSortOrderChange={onSortOrderChange}
            />

            <div className="flex flex-wrap gap-2">
                <button
                    onClick={handleSelectAllWrapper}
                    className="flex items-center space-x-2 px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm"
                >
                    <CheckSquare className="w-4 h-4" />
                    <span>Todas</span>
                </button>

                <button
                    onClick={handleSelectOverdueWrapper}
                    className="flex items-center space-x-2 px-3 py-1.5 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors text-sm"
                >
                    <AlertTriangle className="w-4 h-4" />
                    <span>Vencidas</span>
                </button>

                <button
                    onClick={handleClearSelectionWrapper}
                    className="flex items-center space-x-2 px-3 py-1.5 bg-gray-600 text-white rounded-md hover:bg-gray-700 transition-colors text-sm"
                >
                    <XSquare className="w-4 h-4" />
                    <span>Limpiar</span>
                </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {invoices.map((invoice) => (
                    <InvoiceCard
                        key={invoice.id}
                        invoice={invoice}
                        isSelected={selectedInvoiceIds.has(invoice.id)}
                        onSelectionChange={handleInvoiceSelectionWrapper}
                    />
                ))}
            </div>

              <div className="flex justify-end pt-2">
                <button
                    onClick={handleNext}
                    disabled={!hasSelection}
                    className={`
            px-6 py-2 rounded-md font-semibold transition-all duration-200 text-sm
            ${hasSelection
                            ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-md hover:shadow-lg'
                            : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                        }
          `}
                >
                    Continuar ({selectedInvoiceIds.size} seleccionadas)
                </button>
            </div>
        </div>
    );
};

export const Step1SelectDeudas = memo(Step1SelectDeudasComponent, (prevProps, nextProps) => {
    // Compare the props that affect rendering
    return (
        prevProps.invoices === nextProps.invoices &&
        prevProps.searchTerm === nextProps.searchTerm &&
        prevProps.statusFilter === nextProps.statusFilter &&
        prevProps.sortBy === nextProps.sortBy &&
        prevProps.sortOrder === nextProps.sortOrder
    );
});