// src/App.tsx
import React, { useCallback, useState, useMemo, useEffect } from 'react';
import { useInvoiceContext } from './context/InvoiceContext';
import { useInvoiceManager } from './hooks/useInvoiceManager';
import { Banknote } from 'lucide-react';
import { Step1SelectDeudas } from './components/Step1SelectDeudas';
import { Step0BankSelection } from "./components/Step0BankSelection";
import { Step2ReviewPayment } from './components/Step2ReviewPayment';
import { Step3ConfirmPayment } from './components/Step3ConfirmPayment';
import { Step4Complete } from './components/Step4Complete'; // Corrected import
import { InvoiceProvider } from './context/InvoiceContext';
import { searchClient } from "./api/apiService";
import type { Bank } from './types/invoice';
import { Step5Validating } from './components/Step5Validating';

function App() {
    const key = useMemo(() => Math.random(), [])

    return (
        <InvoiceProvider key={key}>
            <AppContent />
        </InvoiceProvider>
    );
}

function AppContent() {
    const {
        currentStep,
        setCurrentStep,
        selectedBank,
        setSelectedBank,
        cedula,
        setCedula,
        availableBanks,
        setAvailableBanks,
        banksLoaded,
        setBanksLoaded,
        apiError,
        setApiError,
        bankDetails,
        setBankDetails,
        selectedInvoiceIds,
        setSelectedInvoiceIds,
        paymentSummary,
        setPaymentSummary,
        clientData,
        setClientData,
        updatePaymentSummary,
        fetchInvoices,
        invoices,
        isBankDetailsLoading,
        pushReferenceValidationResult,
        paymentCreationResult, //Import Result
        handleStartOver
    } = useInvoiceContext();

    const {
        filteredAndSortedInvoices,
        searchTerm,
        statusFilter,
        sortBy,
        sortOrder,
        handleInvoiceSelection,
        setSearchTerm,
        setStatusFilter,
        setSortBy,
        setSortOrder,
    } = useInvoiceManager(invoices);

    const [cedulaType, setCedulaType] = useState('V');
    const [cedulaNumber, setCedulaNumber] = useState('');
    const [localCedula, setLocalCedula] = useState('');

    const hasSelectedInvoices = selectedInvoiceIds.size > 0;

    const handleNext = useCallback(() => {
        const hasSelected = selectedInvoiceIds.size > 0

        if (currentStep === 1 && !hasSelected) {
            alert("Por favor, seleccione al menos una deuda antes de continuar.");
            return;
        }
        setCurrentStep(Math.min(currentStep + 1, 4));

    }, [currentStep, setCurrentStep, selectedInvoiceIds]);

    const handleBack = useCallback(() => {
        setCurrentStep(Math.max(currentStep - 1, 0));
    }, [setCurrentStep, currentStep]);

    const handleConfirmPayment = useCallback(() => {
        setCurrentStep(4);
    }, [setCurrentStep]);

   const handleCedulaNumberChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        // Allow only numbers
        if (/^\d*$/.test(value)) {
            setCedulaNumber(value);
        }
    }, [setCedulaNumber]);

    const handleSearchBanks = useCallback(async () => {
        if (cedulaType && cedulaNumber) {
            const fullCedula = cedulaType + cedulaNumber;
            setCedula(fullCedula);
            setLocalCedula(fullCedula)

            setApiError(null);
            try {
                const apiUrl = import.meta.env.VITE_API_URL;
                const apiToken = import.meta.env.VITE_API_TOKEN;

                const clientResponse = await searchClient(fullCedula, apiToken);

                if (clientResponse.status && clientResponse.cliente) {
                    setClientData(clientResponse);
                    const clientId = clientResponse.cliente.id.toString();
                    fetchInvoices(fullCedula, apiToken);
                    setCurrentStep(1);

                } else {
                    setApiError(clientResponse.message || "Cliente no encontrado.");
                    setAvailableBanks([]);
                    setBanksLoaded(false);
                    setSelectedBank(null);
                    setClientData(null);
                }
            } catch (error: any) {
                console.error("Error fetching banks:", error);
                setApiError(error.message || "Error al obtener los bancos.");
                setAvailableBanks([]);
                setBanksLoaded(false);
                setSelectedBank(null);
                setClientData(null);
            }
        } else {
            alert("Por favor, ingrese la cédula.");
        }
    }, [cedulaType, cedulaNumber, setAvailableBanks, setApiError, setBanksLoaded, setCurrentStep, setSelectedBank, setClientData, fetchInvoices, setCedula]);

    useEffect(() => {
        if (pushReferenceValidationResult && pushReferenceValidationResult.status) {
            setCurrentStep(5);
        }
    }, [pushReferenceValidationResult, setCurrentStep]);

        useEffect(() => {
        if (paymentCreationResult && paymentCreationResult.status) {
           setCurrentStep(6);  //Move direclty to complete if push is true.
        }
    }, [paymentCreationResult, setCurrentStep]);

    let content;

    switch (currentStep) {
        case 0:
            content = (
                <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 md:p-8">
                    <div className="mb-4 md:mb-6">
                        <label htmlFor="cedula" className="block text-gray-700 text-sm font-bold mb-2">
                            Cédula:
                        </label>
                        <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2">
                            <select
                                value={cedulaType}
                                onChange={(e) => setCedulaType(e.target.value)}
                                className="shadow appearance-none border rounded w-1/4 py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                            >
                                <option value="V">V</option>
                                <option value="E">E</option>
                                <option value="J">J</option>
                                <option value="G">G</option>
                            </select>
                            <input
                                type="text"
                                id="cedula"
                                value={cedulaNumber}
                                onChange={handleCedulaNumberChange}
                                className="shadow appearance-none border rounded w-3/4 py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                                placeholder="Ingresa tu cédula"
                            />
                            <button
                                onClick={handleSearchBanks}
                                className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                                type="button"
                            >
                                Buscar
                            </button>
                        </div>

                        {apiError && (
                            <div className="mt-4 text-red-500">
                                Error: {apiError}
                            </div>
                        )}
                    </div>

                </div>
            );
            break;
        case 1:
            content = (
                <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 md:p-8">
                    <Step1SelectDeudas
                        invoices={filteredAndSortedInvoices}
                        searchTerm={searchTerm}
                        statusFilter={statusFilter}
                        sortBy={sortBy}
                        sortOrder={sortOrder}
                        onSearchChange={setSearchTerm}
                        onStatusFilterChange={setStatusFilter}
                        onSortChange={setSortBy as (sortBy: "dueDate" | "amount" | "supplier") => void}
                        onSortOrderChange={setSortOrder}
                    />
                </div>
            );
            break;
        case 2:
            content = (
                <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 md:p-8">
                    {banksLoaded && availableBanks.length > 0 ? (
                        <Step0BankSelection />
                    ) : (
                        <p>Cargando bancos disponibles...</p>
                    )}
                </div>
            );
            break;
        case 3:
            content = (
                <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 md:p-8">
                    <Step2ReviewPayment
                        summary={paymentSummary}
                    />
                </div>
            );
            break;
        case 4:
            content = (
                <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 md:p-8">
                    <Step3ConfirmPayment
                        summary={paymentSummary}
                    />
                </div>
            );
            break;
        case 5:
            content = (
                <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 md:p-8">
                    <Step5Validating />
                </div>
            );
            break;
         case 6:
                content = (
                  <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 md:p-8">
                    <Step4Complete
                        summary={paymentSummary}
                        onStartOver={handleStartOver}
                    />
                  </div>
                 );
              break;
        default:
            content = (
                <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 md:p-8">
                    <p>Página no encontrada</p>
                </div>
            );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-gray-50 flex items-center justify-center">
            <div className="container mx-auto px-4 py-8 max-w-4xl">
                <div className="text-center mb-8">
                    <div className="flex items-center justify-center space-x-3 mb-4">
                        <div className="bg-blue-600 p-3 rounded-full">
                            <Banknote className="w-8 h-8 text-white" />
                        </div>
                        <h1 className="text-3xl md:text-4xl font-bold text-gray-900">
                            Sistema de Pagos de Deudas
                        </h1>
                    </div>
                    <p className="text-lg md:text-xl text-gray-600 max-w-2xl mx-auto">
                        Procesa tus pagos de deudas de forma rápida y segura.
                    </p>
                </div>

                {content}

            </div>
        </div>
    );
}

export default App;